<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>Авторизация</title>
    </head>
    <body>
        <div>  
            <form action="login.php" method="post" style=" width: 200px; height: 50px; background: #cecece; padding: 10px; cursor: pointer;">
                <input type="text" name="login" required placeholder="Логин"><br>
                <input type="password" name="password" required placeholder="Пароль"><br>
                <input type="submit" name="batton" value="Авторизация">
            </form>
    </body>
</html>