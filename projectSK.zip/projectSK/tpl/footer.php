            <!--footer-->
            <div id="footer">
                <div class="footerConteiner">
                    <div class="footerText1">
                        <div id="footerLogoS">
                            <div class="logoSk">
                                <a href="index.php"> <img src="images/logo maSKel.png" height="50"></a>
                            </div>
                        </div>
                    </div>
                    <div class="footerText2">
                        <div class="text2">
                            <div class="text2Block">
                                <div class="block">
                                    <p class="blockH1">В этом мы профессионалы 
                                    </p>
                                    <div class="blockText">
                                        <ul class="textMenu">
                                            <li class="menu_1"><a class="footer2Block" href="services.php#info1">Архитектурно-строительное проектирование<span></span></a>
                                            </li>
                                            <li class="menu_1"><a class="footer2Block" href="services.php#info2">Строительство жилья "под ключ"<span></span></a>
                                            </li>
                                            <li class="menu_1"><a class="footer2Block" href="services.php#info3">Реставрация и ремонт<span></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="text2Block">
                                <div class="block">
                                    <p class="blockH2">Это Вас заинтересует </p>
                                    <div class="blockText">
                                        <ul class="textMenu">
                                            <li class="menu_2"><a class="footer2Block" href="projects.php#dd1Services">Продажа готовых объектов недвижимости<span></span></a>
                                            </li>
                                            <li class="menu_2"><a class="footer2Block" href="aboutUs.php">О Компании<span></span></a></li>
                                            <li class="menu_2 _footer"><a class="registrationButton" href="index.php#formGlobal"><span>ВАШ ИНДИВИДУАЛЬНЫЙ ЗАПРОС</span></a></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="text2Block contacts">
                                <div class="block">
                                    <p class="blockH3">Наши контакты </p>
                                    <div class="blockText">
                                        <ul class="textMenu">
                                            <li class="menu_3"><a class="footer2BlockContacts">Офис: Plaça de la Fruita 6, Elche,<br> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp Alicante, Espańa</a>
                                            </li>
                                            <li class="menu_3"><a class="footer2BlockContacts">Телефоны: +34 652 288 666 <br>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp+34 675 354 594</a></li>
                                            <li class="menu_3"><a class="footer2BlockContacts"> e-mail: sk@maskeles.com </a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="footerText3">
                        <div class="footerCopyright">
                            <div class="logoOk">
                                <img src="images/logoOk.png" width="40">
                            </div>
                            <div class="textCopyright">
                                <p class="copyright">
                                    Copyright 2018 · 
                                    All rights reserved · 
                                    Made in Elche (Spain)
                                </p>
                            </div>
                            <div class="textCopyright adress">
                                <p class="copyright">
                                Grupo Surcos, Calle Gilberto Martínez 27, Elche (Spain) 03204
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                        <!--end footer-->
        </div>
            <!--scripts-->
        <script type="text/javascript" src="js/jquery-3.3.1.js"></script>
        <script type="text/javascript" src="js/img.js"></script>
        <script type="text/javascript" src="js/up.js"></script>
        <script type="text/javascript" src="js/header.js"></script>
        <script type="text/javascript" src="js/body.js"></script>
        <script type="text/javascript" src="js/about.js"></script>
        <div id="toTop"><img src="images/up.png"></div>
    </body>
</html>
