/*$('.blockH1').click(function() {
    $('.menu_1').css({
        'display': 'block'
    });
});

$('.blockH2').click(function() {
    $('.menu_2').css({
        'display': 'block'
    });
});

$('.blockH3').click(function() {
    $('.menu_3').css({
        'display': 'block'
    });
});

