
$(window).scroll(function() {
	if ($(this).scrollTop() > 150){
		$('#left2').css("display", "block");
		$('#right2').css("display", "block");
		$('#left2').addClass("sticky");
		$('#right2').addClass("sticky");
	}
	else{

	}
});

$(window).scroll(function() {
	if ($(this).scrollTop() > 300){
		$('#apartmentBox').css("display", "block");
		$('#apartmentBox').addClass("sticky");
		$('#imgLeft1').css("display", "block");
		$('#imgLeft1').addClass("sticky");
		$('#textRight1').css("display", "block");
		$('#textRight1').addClass("sticky");
	}
	else{

	}
});

$(window).scroll(function() {
	if ($(this).scrollTop() > 400){
		$('#textFut').css("display", "block");
		$('#textFut').addClass("sticky");
	}
	else{

	}
});

$(window).scroll(function() {
	if ($(this).scrollTop() > 750){
		$('#textLeft2').css("display", "block");
		$('#textLeft2').addClass("sticky");
		$('#imgRight2').css("display", "block");
		$('#imgRight2').addClass("sticky");
	}
	else{

	}
});

$(window).scroll(function() {
	if ($(this).scrollTop() > 1200){
		$('#imgLeft3').css("display", "block");
		$('#imgLeft3').addClass("sticky");
		$('#textRight3').css("display", "block");
		$('#textRight3').addClass("sticky");
	}
	else{

	}
});

$(window).scroll(function() {
	if ($(this).scrollTop() > 1600){
		$('#textLeft4').css("display", "block");
		$('#textLeft4').addClass("sticky");
		$('#imgRight4').css("display", "block");
		$('#imgRight4').addClass("sticky");
	}
	else{

	}
});

$(window).scroll(function() {
	if ($(this).scrollTop() > 2000){
		$('#imgLeft5').css("display", "block");
		$('#imgLeft5').addClass("sticky");
		$('#textRight5').css("display", "block");
		$('#textRight5').addClass("sticky");
	}
	else{

	}
});

$(window).scroll(function() {
	if ($(this).scrollTop() > 2400){
		$('#textLeft6').css("display", "block");
		$('#textLeft6').addClass("sticky");
		$('#imgRight6').css("display", "block");
		$('#imgRight6').addClass("sticky");
	}
	else{

	}
});














