
var form = document.getElementById("catalogFormsContainerCat");
var result = document.getElementById("ip-listing-101049");
function getResult() {
  form.classList.hiden();
}


