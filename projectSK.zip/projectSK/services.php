﻿<?php require 'tpl/header.php'?>
            <div class="dd1Services">
                <div id="cotainerImg"></div>
                <div class="servContainerBox">
                    <div class="cotainerText">
                        <div class="textH">
                            <p class="pH">Наши услуги</p>
                        </div>
                        <div class="servicesImg">
                            <div class="servicesImgText">
                                <a class="imgText left1" href="#"><img src="images/servis3.png" alt="Архитектуро-строительное проектирование" width="120" height="120"> Архитектуро-строительное проектирование</a>
                                <a class="imgText left2" href="services.php#info2"><img src="images/servis1.png" alt="Строительство и ремонт" width="120" height="120"> Строительство любого типа нежвижимости</a>
                                <a class="imgText right1" href="services.php#info3"><img src="images/servis5.png" alt="Продажа недвижимости" width="120" height="120"> Реставрация и ремонт любой сложности</a>
                                <a class="imgText right2" href="services.php#info4"><img src="images/servis4.png" alt="Юридическая помощь" width="120" height="120"> Юридическая помощь в оформлении документов</a>
                            </div>
                        </div>
                        <div class="servicesInfo" id="info1">
                            <div class="infoH">
                                <p class="table" id="#projects">Архитектурно-строительное проектирование</p>
                            </div>
                            <div class="tableImg">
                                <div class="imgImages">
                                    <div class="_imgImg"><img src="images/imgUs/img11.jpg" width="310" height="250"></div>
                                </div>
                                <div class="imgImages">
                                    <div class="_imgImg"><img src="images/imgUs/img12.jpg" width="310" height="250"></div>
                                </div>
                                <div class="imgImages">
                                    <div class="_imgImg"><img src="images/imgUs/img13.jpg" width="310" height="250"></div>
                                </div>
                            </div>
                            <div class="tableText"></div>
                        </div>
                        <div class="servicesInfo" id="info2">
                            <div class="infoH">
                                <p class="table">Строительство любого типа нежвижимости</p>
                            </div>
                            <div class="tableImg">
                                <div class="imgImages">
                                    <div class="_imgImg"><img src="images/imgUs/img21.jpg" width="310" height="250"></div>
                                </div>
                                <div class="imgImages">
                                    <div class="_imgImg"><img src="images/imgUs/img22.jpg" width="310" height="250"></div>
                                </div>
                                <div class="imgImages">
                                    <div class="_imgImg"><img src="images/imgUs/img23.jpg" width="310" height="250"></div>
                                </div>
                            </div>
                            <div class="tableText"></div>
                        </div>
                        <div class="servicesInfo" id="info3">
                            <div class="infoH">
                                <p class="table">Реставрация и ремонт любой сложности</p>
                            </div>
                            <div class="tableImg">
                                <div class="imgImages">
                                    <div class="_imgImg"><img src="images/imgUs/img31.jpg" width="310" height="250"></div>
                                </div>
                                <div class="imgImages">
                                    <div class="_imgImg"><img src="images/imgUs/img32.jpg" width="310" height="250"></div>
                                </div>
                                <div class="imgImages">
                                    <div class="_imgImg"><img src="images/imgUs/img33.jpg" width="310" height="250"></div>
                                </div>
                            </div>
                            <div class="tableText"></div>
                        </div>
                        <div class="servicesInfo" id="info4">
                            <div class="infoH">
                                <p class="table">Юридическая помощь в оформлении документов</p>
                            </div>
                            <div class="tableImg">
                                <div class="imgImages">
                                    <div class="_imgImg"><img src="images/imgUs/img41.jpg" width="310" height="250"></div>
                                </div>
                                <div class="imgImages">
                                    <div class="_imgImg"><img src="images/imgUs/img42.jpg" width="310" height="250"></div>
                                </div>
                                <div class="imgImages">
                                    <div class="_imgImg"><img src="images/imgUs/img43.jpg" width="310" height="250"></div>
                                </div>
                            </div>
                            <div class="tableText"></div>
                        </div>
                    </div>
                </div>
            </div>
<?php require 'tpl/footer.php'?>


